<p align="center">
    <a href="https://www.iviewui.com">
        <img width="200" src="https://raw.githubusercontent.com/iview/iview/master/assets/logo.png">
    </a>
</p>

# iView-cli

### A visual CLI for scaffolding iView projects and offline doc of iView .

## Features

- Visual
- Configuring simply
- Support both Mac and Windows
- It is quite beautiful

## Screenshot


## Donation
iView-cli is an MIT licensed open source project and completely free to use, but if it is helpful to you, you can buy me a coffee :)

<p align="center">
    <img src="https://raw.githubusercontent.com/iview/iview/master/assets/pay.png">
</p>
